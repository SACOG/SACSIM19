
CREATE TABLE {} (
	[I] [real] NULL,
	[C2_VT_I] [real] NULL,
	[C3_VT_I] [real] NULL,
	[C2_VHT_I] [real] NULL,
	[C3_VHT_I] [real] NULL,
	[C2_VMT_I] [real] NULL,
	[C3_VMT_I] [real] NULL,
	[C2_CVMT_I] [real] NULL,
	[C3_CVMT_I] [real] NULL
)


